﻿namespace Blog.API.Models.DTOs
{
    public class UpdateCategoryRequestDto
    {
        public string Name { get; set; }
        public string UrlHandle { get; set; }
    }
}
