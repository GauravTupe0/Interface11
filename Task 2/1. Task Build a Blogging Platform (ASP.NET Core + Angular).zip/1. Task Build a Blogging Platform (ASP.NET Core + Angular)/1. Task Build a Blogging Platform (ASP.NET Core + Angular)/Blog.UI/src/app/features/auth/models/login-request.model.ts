export interface LoginRequest {
    userName: string;
    password: string;
}