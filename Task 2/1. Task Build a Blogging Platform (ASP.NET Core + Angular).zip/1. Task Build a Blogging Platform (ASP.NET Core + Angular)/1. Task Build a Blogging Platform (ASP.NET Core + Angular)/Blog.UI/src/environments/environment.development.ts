export const environment = {
    apiBaseUrl: 'https://asblogapi.azurewebsites.net'
};
