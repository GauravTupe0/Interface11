using Microsoft.AspNetCore.Mvc; 
using Microsoft.EntityFrameworkCore; 
using ProductCatalogAPI.Data; 
using ProductCatalogAPI.Models; 
namespace ProductCatalogAPI.Controllers { 
    [Route("api/[controller]")] 
    [ApiController] 
    public class ProductsController : ControllerBase { 
        private readonly ProductDbContext _context; 
        public ProductsController(ProductDbContext context) { 
            _context = context; 
        } 
        [HttpGet] 
            var products = string.IsNullOrEmpty(category) 
                ? await _context.Products.ToListAsync() 
                : await _context.Products.Where(p = == category).ToListAsync(); 
            return Ok(products); 
        } 
        [HttpGet("{id}")] 
            var product = await _context.Products.FindAsync(id); 
            if (product == null) return NotFound(); 
            return Ok(product); 
        } 
    } 
} 
