using Microsoft.EntityFrameworkCore; 
using ProductCatalogAPI.Models; 
namespace ProductCatalogAPI.Data { 
    public class ProductDbContext : DbContext { 
    } 
} 
