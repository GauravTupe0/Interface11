﻿namespace AuthECAPI.Controllers
{
    public static class OrderEndpoints
    {

    }
}
