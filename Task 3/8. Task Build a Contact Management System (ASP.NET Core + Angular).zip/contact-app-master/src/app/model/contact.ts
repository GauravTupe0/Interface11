export interface IContact {
    id: number;
    name: string;
    email: string;
    gender: number;
    birth: string;
    techno: string;
    message: string;
}
