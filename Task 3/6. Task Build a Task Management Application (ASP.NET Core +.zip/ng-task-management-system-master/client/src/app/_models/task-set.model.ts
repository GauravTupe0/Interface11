import TaskModel from "./task.model";

export default class TaskSetModel {
    tasks?: TaskModel[];
    totalCount: number;
}
