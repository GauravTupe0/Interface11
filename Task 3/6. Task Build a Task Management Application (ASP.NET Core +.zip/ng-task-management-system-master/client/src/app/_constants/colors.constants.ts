export const BlackHex = "#000000";
export const WhiteHex = "#FFFFFF";
export const DangerHex = "#e91224";
export const WarningHex = "#FF7F50";
export const SuccessHex = "#34a835";
export const DarkedRedHex = "#8B0000";
export const LightGrayHex = "#DCDCDC";
export const LightYellowHex = "#FFFACD";
