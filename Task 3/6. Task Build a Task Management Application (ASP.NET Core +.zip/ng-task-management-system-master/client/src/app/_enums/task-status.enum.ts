export enum ETaskStatus {
  Active = 0,
  Completed = 1,
  Archived = 2
}
