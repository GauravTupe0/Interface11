export const environment = {
  production: false,
  API_URL: "http://localhost:8001"
};
