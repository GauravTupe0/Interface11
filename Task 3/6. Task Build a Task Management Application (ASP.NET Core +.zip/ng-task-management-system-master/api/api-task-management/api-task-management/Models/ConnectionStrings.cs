﻿public class ConnectionStrings
{
    public string TasksDb { get; set; }

    public string Seq { get; set; }
}